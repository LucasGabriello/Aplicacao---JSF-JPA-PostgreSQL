package br.com.dominio.utility;

public class PersonalException extends Exception {

	private static final long serialVersionUID = 1L;

	public PersonalException(String message) {
		super(message);
	}
}
