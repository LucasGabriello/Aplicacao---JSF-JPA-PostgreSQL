package br.com.Gerenciamento.model;

public interface BaseTarefa {
	public Long getIdTarefa();
}
