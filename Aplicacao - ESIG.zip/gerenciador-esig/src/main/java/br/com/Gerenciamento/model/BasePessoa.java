package br.com.Gerenciamento.model;

public interface BasePessoa {
	public Long getIdPessoa();
}
